<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="terrain_tileset" tilewidth="32" tileheight="32" tilecount="297" columns="27">
 <properties>
  <property name="Transparent Color" type="color" value="#00000000"/>
 </properties>
 <image source="../tiles/terrain_tileset.png" width="864" height="352"/>
</tileset>
