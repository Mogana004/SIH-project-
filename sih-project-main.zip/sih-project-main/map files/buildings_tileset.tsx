<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="buildings_tileset" tilewidth="32" tileheight="32" tilecount="418" columns="38">
 <image source="../tiles/buildings_tileset.png" width="1216" height="352"/>
</tileset>
