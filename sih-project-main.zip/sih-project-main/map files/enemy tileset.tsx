<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="enemy tileset" tilewidth="32" tileheight="32" tilecount="2" columns="2">
 <image source="../tiles/enemy_tileset.png" width="64" height="32"/>
</tileset>
