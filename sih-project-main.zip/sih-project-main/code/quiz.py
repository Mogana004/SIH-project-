import pygame
from settings import *
from button import Button


class Quiz:
    def __init__(self, surface, question, answers, correct_answer):
        self.font = pygame.font.SysFont('Arial', 20)
        self.font_color = (0, 0, 0)
        
        QUIZ_PANEL_DIMENSIONS = (screen_width / 3, screen_height)

        quiz_rect = pygame.Rect(screen_width - QUIZ_PANEL_DIMENSIONS[0], 0, QUIZ_PANEL_DIMENSIONS[0], QUIZ_PANEL_DIMENSIONS[1])
        pygame.draw.rect(surface, (255, 255, 255), quiz_rect)

        # display the question on the rectangle and wrap the text if necessary
        question_lines = self.wrap_text(question, self.font, QUIZ_PANEL_DIMENSIONS[0] - 40)
        question_surface = self.render_text_list(surface, question_lines, quiz_rect, self.font, self.font_color)
        

        for scale, option in enumerate(answers):
            button = Button(self.font_color, quiz_rect.x + 20, quiz_rect.y + 80 + (scale + 1 ) * 80, QUIZ_PANEL_DIMENSIONS[0] - 40, 50, f"{option}")
            button.draw(surface, outline=True)
            if button.isOver(pygame.mouse.get_pos()):
                if pygame.mouse.get_pressed()[0]:
                    if button.text == correct_answer:
                        button = Button(self.font_color, quiz_rect.x + 20, quiz_rect.y + 80 + (scale + 1 ) * 80, QUIZ_PANEL_DIMENSIONS[0] - 40, 50, "Correct!")
                        button.draw(surface, outline=True)
                    else:
                        button = Button(self.font_color, quiz_rect.x + 20, quiz_rect.y + 80 + (scale + 1 ) * 80, QUIZ_PANEL_DIMENSIONS[0] - 40, 50, "Incorrect :[")
                        button.draw(surface, outline=True)






    def wrap_text(self, text, font, width):
        """
        Wrap text to fit inside a given width when rendered.
        :param text: The text to be wrapped.
        :param font: The font the text will be rendered in.
        :param width: The width to wrap to.
        """
        text_lines = text.replace('\t', '    ').split('\n')
        if width is None or width == 0:
            return text_lines

        wrapped_lines = []
        for line in text_lines:
            line = line.rstrip() + ' '
            if line == ' ':
                wrapped_lines.append(line)
                continue

            # Get the leftmost space ignoring leading whitespace
            start = len(line) - len(line.lstrip())
            start = line.index(' ', start)
            while start + 1 < len(line):
                # Get the next potential splitting point
                next = line.index(' ', start + 1)
                if font.size(line[:next])[0] <= width:
                    start = next
                else:
                    wrapped_lines.append(line[:start])
                    line = line[start+1:]
                    start = line.index(' ')
            line = line[:-1]
            if line:
                wrapped_lines.append(line)
        return wrapped_lines


    def render_text_list(self, surface, lines, quiz_rect, font, colour=(0, 0, 0)):
        """Draw multiline text to a single surface with a transparent background.
        Draw multiple lines of text in the given font onto a single surface
        with no background colour, and return the result.
        :param lines: The lines of text to render.
        :param font: The font to render in.
        :param colour: The colour to render the font in, default is white.
        """
        rendered = [font.render(line, True, colour).convert_alpha()
                    for line in lines]

        line_height = font.get_linesize() + 5
        width = max(line.get_width() for line in rendered)
        tops = [int(round(i * line_height)) for i in range(len(rendered))]
        height = tops[-1] + font.get_height()

        for y, line in zip(tops, rendered):
            surface.blit(line, (quiz_rect.x + 20, y + 20))

        return surface
