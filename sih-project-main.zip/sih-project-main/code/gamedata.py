level_0 = {
    'terrain': '../levels/0/level_terrain.csv',
    'player': '../levels/0/level_player.csv',
    'enemy': '../levels/0/level_enemy.csv',
    'contraints': '../levels/0/level_constraints.csv',
    'upward_ramps': '../levels/0/level_upward_ramps.csv',
    'downward_ramps': '../levels/0/level_downward_ramps.csv',
    'decorations': '../levels/0/level_decorations.csv',
}
