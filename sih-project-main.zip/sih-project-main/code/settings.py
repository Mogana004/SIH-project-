level_map = [
    '                         ',
    '                         ',
    '                         ',
    '                         ',
    '                         ',
    '                         ',
    '     p   xxxxxxx         ',
    '     xxxxxxx             ',
    '                         ',
    '                         ',
    '               xxxxxxxxxx',
    'xxxxxxxxxxxxxxxxxxxxxxxxx',
]

tile_size = 32
screen_width = 1000
screen_height = len(level_map) * tile_size
