import pygame


class Button():
    def __init__(self, x, y, image, scale):
        width = image.get_width()
        height = image.get_height()

        self.image = pygame.transform.scale(image, (int(width * scale), int(height * scale)))
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.clicked = False

    def draw(self):
        pos = pygame.mouse.get_pos()
        # is mouse hovering over button?
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                self.clicked = True
                print("Clicked")
        screen.blit(self.image, self.rect)

start_btn_img = pygame.image.load("assets/start_btn.png")
start_btn = Button(100, 100, start_btn_img, 0.25)


class Game:
    def __init__(self):
        pygame.init()
        DIMENSIONS = X, Y = (1200, 450)

        self.screen = pygame.display.set_mode(DIMENSIONS)
        pygame.display.set_caption("Learn Python With RazorCode!")

        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font('Arial', 32)

        self.screen.fill((255, 255, 255))


    




    
