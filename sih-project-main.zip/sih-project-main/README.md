# Learn Python With RazorCode

RazorCode offers a gamified approach to learning the python programming language.

The game is created solely using Python and Pygame.

### Planned Features
+ AI powered dashboard to analyse and track user's progress
+ Multiple interactive byte sized lessons to teach Python basics
+ Multiple playable mini-games integrated with lessons
+ Multiplayer mode to allow users to play a match with their friends
